# VB6 with ADO/SQL and VBA to Word-example


embedded SQL to link to MS Access and embedded VBA for report output. Created to help me output evidence during teacher training course at university. Strong use of coding conventions and techniques, producing readable and maintainable algorithms.



Built in Visual Basic 6
Was involved in many large scale applications (leading development on several) during my time working for Gala Group, but have decided not to post any of that code so as to not infringe on their intellectual property. I'm focusing on uploading smaller, personal projects.






Any questions, email danpick77@gmail.com :-)